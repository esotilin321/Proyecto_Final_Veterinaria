package proyecto_final_veterinaria;

import java.util.ArrayList;

/**
 *
 * @author Jean Purizaga
 */
public class Administrador extends Usuario{
    
    private ArrayList<ReporteAdministrador> reportes = new ArrayList<>();

    public Administrador(String idUsuario, String nombre_Usuario, String correo_Usuario, String contraseña_Usuario) {
        super(idUsuario, nombre_Usuario, correo_Usuario, contraseña_Usuario);
    }
    
    @Override
    public void iniciarSesion() {
        System.out.println("Administrador inicio sesion");
    }

    @Override
    public void cerrarSesion() {
        System.out.println("Administrador cerro sesion");
    }
    
    public void gestionarReporte(ReporteAdministrador r) {
        reportes.add(r);
        System.out.println("Reporte agregado correctamente");
    }

    public void gestionarMascotas() {
        System.out.println("Gestion de mascotas completada");
    }

    public void gestionarServicios() {
        System.out.println("Gestion de servicios medicos completada");
    }
    
    public void mostrarReportes() {
        System.out.println("Lista de reportes actual: ");
        
        for (int i = 0; i < reportes.size(); i++) {
            ReporteAdministrador r = reportes.get(i);
            r.mostrarReporte();
            System.out.println("----------------");
        }
    }
}
