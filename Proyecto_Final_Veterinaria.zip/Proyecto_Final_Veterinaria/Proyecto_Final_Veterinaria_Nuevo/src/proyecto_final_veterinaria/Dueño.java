package proyecto_final_veterinaria;

/**
 *
 * @author Jean Purizaga
 */
public class Dueño extends Usuario{

    private Mascota mascota;

    public Dueño(String idUsuario, String nombre_Usuario, String correo_Usuario, String contraseña_Usuario) {
        super(idUsuario, nombre_Usuario, correo_Usuario, contraseña_Usuario);
    }
    
    @Override
    public void iniciarSesion() {
        System.out.println("El Dueño " + getNombre_Usuario() + " ha iniciado sesión.");
    }

    @Override
    public void cerrarSesion() {
        System.out.println("El Dueño " + getNombre_Usuario() + " ha cerrado sesión.");
    }
    
}
