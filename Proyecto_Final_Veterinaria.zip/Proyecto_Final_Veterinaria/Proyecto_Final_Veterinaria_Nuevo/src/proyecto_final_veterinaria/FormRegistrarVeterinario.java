package proyecto_final_veterinaria;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class FormRegistrarVeterinario extends JFrame {

    private ArrayList<Usuario> listaUsuarios;
    private ArrayList<Veterinario> listaVeterinarios;

    private JTextField txtId, txtNombre, txtPaterno, txtMaterno, txtTelefono, txtCorreo;
    private JPasswordField txtPassword;
    private JComboBox<String> cbTipoDoc;
    private JTextField txtNroDoc;
    
    private JTextField txtEspecialidad, txtColegiatura;

    public FormRegistrarVeterinario(ArrayList<Usuario> listaUsuarios, ArrayList<Veterinario> listaVeterinarios) {
        this.listaUsuarios = listaUsuarios;
        this.listaVeterinarios = listaVeterinarios;

        setTitle("Registrar Veterinario");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Panel principal
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(240, 248, 255));

        // Header
        JPanel header = new JPanel();
        header.setBackground(new Color(33, 97, 140));
        header.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        JLabel lblTitulo = new JLabel(" Registrar Nuevo Veterinario");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(Color.WHITE);
        header.add(lblTitulo);

        // Formulario
        JPanel formulario = new JPanel(new GridLayout(1, 2, 15, 10));
        formulario.setBackground(new Color(240, 248, 255));
        formulario.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        JPanel panelDatosBasicos = new JPanel(new GridLayout(8, 2, 10, 10));
        panelDatosBasicos.setBackground(new Color(240, 248, 255));
        panelDatosBasicos.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), "Datos Básicos", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new Font("Arial", Font.BOLD, 12), Color.BLACK));

        JPanel panelDatosProfesionales = new JPanel(new GridLayout(3, 2, 10, 10));
        panelDatosProfesionales.setBackground(new Color(240, 248, 255));
        panelDatosProfesionales.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), "Datos Profesionales", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new Font("Arial", Font.BOLD, 12), Color.BLACK));
        
        JPanel panelProfWrapper = new JPanel(new BorderLayout());
        panelProfWrapper.setBackground(new Color(240, 248, 255));
        panelProfWrapper.add(panelDatosProfesionales, BorderLayout.NORTH);

        cbTipoDoc   = new JComboBox<>(new String[]{"DNI", "CE"});
        txtNroDoc   = new JTextField();

        txtId       = new JTextField();
        txtNombre   = new JTextField();
        txtPaterno  = new JTextField();
        txtMaterno  = new JTextField();
        txtTelefono = new JTextField();
        txtCorreo   = new JTextField();
        txtPassword = new JPasswordField();
        
        txtEspecialidad = new JTextField();
        txtColegiatura = new JTextField();

        panelDatosBasicos.add(new JLabel("ID Usuario:"));        panelDatosBasicos.add(txtId);
        panelDatosBasicos.add(new JLabel("Nombre:"));            panelDatosBasicos.add(txtNombre);
        panelDatosBasicos.add(new JLabel("Ap. Paterno:"));       panelDatosBasicos.add(txtPaterno);
        panelDatosBasicos.add(new JLabel("Ap. Materno:"));       panelDatosBasicos.add(txtMaterno);
        panelDatosBasicos.add(new JLabel("Tipo Doc:"));          panelDatosBasicos.add(cbTipoDoc);
        panelDatosBasicos.add(new JLabel("Nro Doc:"));           panelDatosBasicos.add(txtNroDoc);
        panelDatosBasicos.add(new JLabel("Teléfono:"));          panelDatosBasicos.add(txtTelefono);
        panelDatosBasicos.add(new JLabel("Contraseña:"));        panelDatosBasicos.add(txtPassword);

        panelDatosProfesionales.add(new JLabel("Correo:"));          panelDatosProfesionales.add(txtCorreo);
        panelDatosProfesionales.add(new JLabel("Especialidad:"));    panelDatosProfesionales.add(txtEspecialidad);
        panelDatosProfesionales.add(new JLabel("Nro Colegiatura:")); panelDatosProfesionales.add(txtColegiatura);

        formulario.add(panelDatosBasicos);
        formulario.add(panelProfWrapper);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.setBackground(new Color(240, 248, 255));

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(new Color(39, 174, 96));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setFont(new Font("Arial", Font.BOLD, 13));
        btnGuardar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBackground(new Color(231, 76, 60));
        btnLimpiar.setForeground(Color.WHITE);
        btnLimpiar.setFocusPainted(false);
        btnLimpiar.setFont(new Font("Arial", Font.BOLD, 13));
        btnLimpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        panelBotones.add(btnGuardar);
        panelBotones.add(btnLimpiar);

        // Acción Guardar
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id     = txtId.getText().trim();
                String nombre = txtNombre.getText().trim();
                String paterno = txtPaterno.getText().trim();
                String materno = txtMaterno.getText().trim();
                String tipoDoc = (String) cbTipoDoc.getSelectedItem();
                String nroDoc = txtNroDoc.getText().trim();
                String tel    = txtTelefono.getText().trim();
                String correo = txtCorreo.getText().trim();
                String pass   = new String(txtPassword.getPassword());
                
                String especialidad = txtEspecialidad.getText().trim();
                String colegiatura = txtColegiatura.getText().trim();

                // Validar campos vacíos
                if (id.isEmpty() || nombre.isEmpty() || paterno.isEmpty() || materno.isEmpty() || tel.isEmpty() || 
                    correo.isEmpty() || pass.isEmpty() || nroDoc.isEmpty() || especialidad.isEmpty() || colegiatura.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor complete todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Validar DNI / CE
                if ("DNI".equals(tipoDoc) && !nroDoc.matches("\\d{8}")) {
                    JOptionPane.showMessageDialog(null, "El DNI debe tener exactamente 8 dígitos numéricos.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                } else if ("CE".equals(tipoDoc) && !nroDoc.matches("\\d{9}")) {
                    JOptionPane.showMessageDialog(null, "El CE debe tener exactamente 9 dígitos numéricos.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Validar Correo
                if (!correo.toLowerCase().startsWith("v_")) {
                    JOptionPane.showMessageDialog(null, "El correo del veterinario debe iniciar siempre con 'v_'.", "Error de validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!correo.contains("@") || !correo.contains(".com")) {
                    JOptionPane.showMessageDialog(null, "El correo debe contener '@' y '.com'.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Validar Contraseña
                if (pass.length() <= 8) {
                    JOptionPane.showMessageDialog(null, "La contraseña debe tener más de 8 caracteres.", "Error de validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (!pass.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
                    JOptionPane.showMessageDialog(null, "La contraseña debe contener al menos un carácter especial.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Validar Unicidad en lista de usuarios
                for (Usuario u : listaUsuarios) {
                    if (u.getIdUsuario().equalsIgnoreCase(id)) {
                        JOptionPane.showMessageDialog(null, "El ID de usuario ya está registrado.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (u.getCorreo_Usuario().equalsIgnoreCase(correo)) {
                        JOptionPane.showMessageDialog(null, "El correo ya está registrado en otra cuenta. Por favor use otro.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (u.getTelefono() != null && u.getTelefono().equals(tel)) {
                        JOptionPane.showMessageDialog(null, "El teléfono ya está registrado en otra cuenta. Por favor verifíquelo.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (u.getNro_documento() != null && u.getNro_documento().equals(nroDoc)) {
                        JOptionPane.showMessageDialog(null, "El número de documento ya está registrado.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (u instanceof Veterinario) {
                        Veterinario v = (Veterinario) u;
                        if (v.getNroColegiatura() != null && v.getNroColegiatura().equals(colegiatura)) {
                            JOptionPane.showMessageDialog(null, "El nro de colegiatura ya está registrado en otro veterinario.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                }

                Veterinario nuevoVet = new Veterinario(id, nombre, correo, pass, especialidad, colegiatura);
                nuevoVet.setPaterno(paterno);
                nuevoVet.setMaterno(materno);
                nuevoVet.setTelefono(tel);
                nuevoVet.setTipo_documento(tipoDoc);
                nuevoVet.setNro_documento(nroDoc);
                
                listaUsuarios.add(nuevoVet);
                listaVeterinarios.add(nuevoVet);
                
                JOptionPane.showMessageDialog(null, "¡Veterinario registrado correctamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                limpiarCampos();
            }
        });

        // Acción Limpiar
        btnLimpiar.addActionListener(e -> limpiarCampos());

        panel.add(header, BorderLayout.NORTH);
        panel.add(formulario, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtPaterno.setText("");
        txtMaterno.setText("");
        cbTipoDoc.setSelectedIndex(0);
        txtNroDoc.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtPassword.setText("");
        txtEspecialidad.setText("");
        txtColegiatura.setText("");
    }
}
