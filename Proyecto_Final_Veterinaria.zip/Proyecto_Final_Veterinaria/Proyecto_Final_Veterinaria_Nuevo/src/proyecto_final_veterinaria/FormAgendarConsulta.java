package proyecto_final_veterinaria;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author Jean Purizaga
 */
public class FormAgendarConsulta extends JFrame {

    private ArrayList<Mascota> listaMascotas;
    private ArrayList<Veterinario> listaVeterinarios;
    private ArrayList<ServicioMedico> listaServicios;
    private ArrayList<Consulta> listaConsultas;
    private int[] idConsultaCounter;

    private JComboBox<String> cbMascota, cbServicio, cbVeterinario;
    private JSpinner spinnerFecha;

    public FormAgendarConsulta(ArrayList<Mascota> listaMascotas,
    ArrayList<Veterinario> listaVeterinarios,
    ArrayList<ServicioMedico> listaServicios,
    ArrayList<Consulta> listaConsultas,
    int[] idConsultaCounter) {
        this.listaMascotas = listaMascotas;
        this.listaVeterinarios = listaVeterinarios;
        this.listaServicios = listaServicios;
        this.listaConsultas = listaConsultas;
        this.idConsultaCounter = idConsultaCounter;

        setTitle("Agendar Consulta");
        setSize(550, 400);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(240, 248, 255));

        // Header
        JPanel header = new JPanel();
        header.setBackground(new Color(33, 97, 140));
        header.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        JLabel lblTitulo = new JLabel("Agendar Servicio / Consulta");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(Color.WHITE);
        header.add(lblTitulo);

        // Formulario
        JPanel formulario = new JPanel(new GridLayout(4, 2, 10, 15));
        formulario.setBackground(new Color(240, 248, 255));
        formulario.setBorder(BorderFactory.createEmptyBorder(25, 30, 15, 30));

        // ComboBox Mascotas
        cbMascota = new JComboBox<>();
        for (Mascota m : listaMascotas) {
            cbMascota.addItem(m.getNombre() + " (" + m.getNombreDueno() + " " + m.getApellidoPaternoDueno() + " " + m.getApellidoMaternoDueno() + ")");
        }

        // ComboBox Servicios
        cbServicio = new JComboBox<>();
        for (ServicioMedico s : listaServicios) {
            cbServicio.addItem(s.getNombreServicio() + " - S./" + s.getPrecio());
        }

        // ComboBox Veterinarios
        cbVeterinario = new JComboBox<>();
        for (Veterinario v : listaVeterinarios) {
            cbVeterinario.addItem(v.getNombre_Usuario() + " - " + v.getEspecialidad());
        }

        SpinnerDateModel dateModel = new SpinnerDateModel();
        spinnerFecha = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy");
        spinnerFecha.setEditor(dateEditor);

        formulario.add(new JLabel("Mascota:"));      formulario.add(cbMascota);
        formulario.add(new JLabel("Servicio:"));     formulario.add(cbServicio);
        formulario.add(new JLabel("Veterinario:"));  formulario.add(cbVeterinario);
        formulario.add(new JLabel("Fecha:"));        formulario.add(spinnerFecha);

        // Botón Agendar
        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBoton.setBackground(new Color(240, 248, 255));

        JButton btnAgendar = new JButton("Agendar Consulta");
        btnAgendar.setBackground(new Color(39, 174, 96));
        btnAgendar.setForeground(Color.WHITE);
        btnAgendar.setFocusPainted(false);
        btnAgendar.setFont(new Font("Arial", Font.BOLD, 13));
        btnAgendar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnAgendar.addActionListener(e -> {
            if (listaMascotas.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay mascotas registradas. Registre una primero.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int idxMascota = cbMascota.getSelectedIndex();
            int idxServicio = cbServicio.getSelectedIndex();
            int idxVeterinario = cbVeterinario.getSelectedIndex();

            if (idxMascota == -1) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione una mascota.", "Falta selección", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (idxServicio == -1) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un servicio.", "Falta selección", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (idxVeterinario == -1) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un veterinario.", "Falta selección", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Date dateObtenida = (Date) spinnerFecha.getValue();
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            String fecha = format.format(dateObtenida);

            Mascota mascota = listaMascotas.get(idxMascota);
            ServicioMedico servicio = listaServicios.get(idxServicio);
            Veterinario veterinario = listaVeterinarios.get(idxVeterinario);

            Consulta nueva = new Consulta(idConsultaCounter[0]++, mascota, veterinario, servicio, fecha);
            listaConsultas.add(nueva);

            JOptionPane.showMessageDialog(null,
                "¡Consulta agendada con éxito!\n" +
                "Mascota: " + mascota.getNombre() + "\n" +
                "Servicio: " + servicio.getNombreServicio() + "\n" +
                "Veterinario: " + veterinario.getNombre_Usuario() + "\n" +
                "Fecha: " + fecha,
                "Consulta Agendada", JOptionPane.INFORMATION_MESSAGE);
        });

        panelBoton.add(btnAgendar);

        panel.add(header, BorderLayout.NORTH);
        panel.add(formulario, BorderLayout.CENTER);
        panel.add(panelBoton, BorderLayout.SOUTH);

        add(panel);
    }
}
